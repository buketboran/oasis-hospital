<?php
session_start();

if (!array_key_exists("user", $_SESSION)) {
    $_SESSION["user"] = null;
}
function get_mysql_connection()
{
    $conn = new mysqli("localhost", "root", "", "oasis_hospital");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

class CarouselItem
{
    public $image;
    public $content;

    function __construct($image, $content)
    {
        $this->image = $image;
        $this->content = $content;
    }
}

class DoctorStatText
{
    public $number;
    public $text;

    function __construct($number, $text)
    {
        $this->number = $number;
        $this->text = $text;
    }
}

class ContactMessage
{
    public $id;
    public $name;
    public $email;
    public $phone;
    public $message;
    public $id_user;

    function __construct($name, $email, $phone, $message, $id_user)
    {
        $this->name = $name;
        $this->email = $email;
        $this->phone = $phone;
        $this->message = $message;
        $this->id_user = $id_user;
    }

    function insert($conn) {
        $sql = $conn->prepare("INSERT INTO contact_message (name, email, phone, message, id_user) VALUES (?, ?, ?, ?, ?)");
        $sql->bind_param("ssssi", $this->name, $this->email, $this->phone, $this->message, $this->id_user);
        $sql->execute();
        $sql->close();
    }
}

class Doctor
{
    public $id;
    public $name;
    public $surname;
    public $email;
    public $profession;
    public $description;
    public $hospital_id;
    public $image;

    function __construct($name, $surname, $email, $profession, $description, $hospital_id, $image)
    {
        $this->name = $name;
        $this->surname = $surname;
        $this->email = $email;
        $this->profession = $profession;
        $this->description = $description;
        $this->hospital_id = $hospital_id;
        $this->image = $image;
    }

    static function getDoctors($conn)
    {
        $doctors = array();
        $query = "SELECT * FROM doctor";
        $result = $conn->query($query);

        while ($row = $result->fetch_assoc()) {
            $doctor = new Doctor($row["name"], $row["surname"], $row["email"], $row["profession"], $row["description"], $row["hospital_id"], $row["image"]);
            $doctor->id = $row["id"];
            array_push($doctors, $doctor);
        }

        return $doctors;
    }

    public static function getDoctor(?mysqli $conn, mixed $docid)
    {
        $sql = "SELECT * FROM doctor WHERE id = " . $docid;
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $doctor = new Doctor($row["name"], $row["surname"], $row["email"], $row["profession"], $row["description"], $row["hospital_id"], $row["image"]);
        $doctor->id = $row["id"];
        return $doctor;
    }

    function getHospital($conn)
    {
        $sql = "SELECT * FROM hospital WHERE id = " . $this->hospital_id;
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $hospital = new Hospital($row["image"], $row["name"], $row["description"], $row["address"]);
        $hospital->id = $row["id"];
        return $hospital;
    }

    public function getAvailableAppointments(?mysqli $conn, string $tomorrow)
    {
        $day_name = date('l', strtotime($tomorrow));

        $sql = $conn->prepare("CALL get_doctor_appointment_times(?, ?, ?)");

        $sql->bind_param("iss", $this->id, $tomorrow, $day_name);
        $sql->execute();
        $result = $sql->get_result();
        $available_appointments = array();
        while ($row = $result->fetch_assoc()) {
            $available_appointment = new DoctorAvailableAppointment($this->id, $day_name, $row["start_time"], $row["is_available"]);
            $available_appointment->id = $row["id"];
            if ($available_appointment->is_available) {
                array_push($available_appointments, $available_appointment);
            }
        }
        return $available_appointments;
    }
}

class Hospital
{
    public $id;
    public $image;
    public $name;
    public $description;
    public $address;

    function __construct($image, $name, $description, $address)
    {
        $this->image = $image;
        $this->name = $name;
        $this->description = $description;
        $this->address = $address;
    }

    static function getHospitals($conn)
    {
        $hospitals = array();

        $query = "SELECT * FROM hospital";
        $result = $conn->query($query);

        while ($row = $result->fetch_assoc()) {
            $hospital = new Hospital($row["image"], $row["name"], $row["description"], $row["address"]);
            $hospital->id = $row["id"];
            array_push($hospitals, $hospital);
        }

        return $hospitals;
    }

    function getDoctors($conn)
    {
        $doctors = array();

        $query = "SELECT * FROM doctors WHERE hospital_id = " . $this->id;
        $result = $conn->query($query);

        while ($row = $result->fetch_assoc()) {
            $doctor = new Doctor($row["name"], $row["surname"], $row["email"], $row["profession"], $row["description"], $row["hospital_id"], $row["image"]);
            $doctor->id = $row["id"];
            array_push($doctors, $doctor);
        }

        return $doctors;
    }

}

class User
{
    public $id;
    public $name;
    public $surname;
    public $email;
    public $password;

    function __construct($name, $surname, $email, $password)
    {
        $this->name = $name;
        $this->surname = $surname;
        $this->email = $email;
        $this->password = $password;
    }

    public static function register(?mysqli $conn, $name, $surname, $email, $password)
    {
        $sql = $conn->prepare("CALL register_user(?, ?, ?, ?)");
        $sql->bind_param("ssss", $name, $surname, $email, $password);
        $sql->execute();;
        $sql->close();
    }

    public static function login(?mysqli $conn, mixed $email, mixed $password)
    {
        $sql = $conn->prepare("CALL get_login_user(?, ?)");
        $sql->bind_param("ss", $email, $password);
        $sql->execute();
        $result = $sql->get_result();
        $row = $result->fetch_assoc();
        if ($row == null) {
            return null;
        }
        $user = new User($row["name"], $row["surname"], $row["email"], $row["password"]);
        $user->id = $row["id"];
        return $user;
    }

    public function getAppointments($conn)
    {
        $sql = "SELECT * FROM appointment WHERE patient_id = " . $this->id;
        $result = $conn->query($sql);
        $appointments = array();
        while ($row = $result->fetch_assoc()) {
            $appointment = new Appointment($row["doctor_id"], $row["patient_id"], $row["date"], $row["appointment_time_id"]);
            $appointment->id = $row["id"];
            array_push($appointments, $appointment);
        }
        usort($appointments, function ($a, $b) {
            return strtotime($a->date) - strtotime($b->date);
        });
        return $appointments;
    }
}

class DoctorAvailableAppointment
{
    public $id;
    public $doctor_id;
    public $day;
    public $start_time;
    public $is_available;

    function __construct($doctor_id, $day, $start_time, $is_available)
    {
        $this->doctor_id = $doctor_id;
        $this->day = $day;
        $this->start_time = $start_time;
        $this->is_available = $is_available;
    }
}

class Appointment
{

    public $id;
    public $doctor_id;
    public $patient_id;
    public $date;
    public $appointment_time_id;

    function __construct($doctor_id, $patient_id, $date, $appointment_time_id)
    {
        $this->doctor_id = $doctor_id;
        $this->patient_id = $patient_id;
        $this->date = $date;
        $this->appointment_time_id = $appointment_time_id;
    }

    public function insert(?mysqli $conn)
    {
        $sql = $conn->prepare("CALL book_appointment(?, ?, ?, ?)");
        $sql->bind_param("iisi", $this->doctor_id, $this->patient_id, $this->date, $this->appointment_time_id);
        $sql->execute();
        $sql->close();
    }


    public function getDoctor($conn)
    {
        $sql = "SELECT * FROM doctor WHERE id = " . $this->doctor_id;
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $doctor = new Doctor($row["name"], $row["surname"], $row["email"], $row["profession"], $row["description"], $row["hospital_id"], $row["image"]);
        $doctor->id = $row["id"];
        return $doctor;
    }

    public function getAppointmentTime($conn)
    {
        $sql = "SELECT * FROM doctor_appointment_time WHERE id = " . $this->appointment_time_id;
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $appointment_time = new DoctorAvailableAppointment($this->doctor_id, $row["day"], $row["start_time"], false);
        $appointment_time->id = $row["id"];
        return $appointment_time;
    }
}