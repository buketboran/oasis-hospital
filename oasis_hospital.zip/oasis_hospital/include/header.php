<style>
    header {
        position: fixed;
        top: 0px;
        left: 0px;
        width: 100vw;
    }


    nav {
        height: 100px;
        background-color: #072562;
        color: #eeeeee;
    }

    nav  {
        grid-column: 1 / -1;
        background-color: #092c74;
        display: grid;
        grid-template-columns: 100px 1fr repeat(4, auto);
        align-items: center;
        gap: 32px;
        padding: 0px 32px;
    }

    nav  > img {
        width: 100px;
        aspect-ratio: 1.4;
    }

    nav  > label {
        font-size: 32px;
        font-weight: bold;
        text-transform: uppercase;
    }

    nav > a {
        color: #eeeeee;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        text-decoration: none;
        text-align: center;
        transition: 300ms;
    }

    nav  > a:hover {
        color: #db545a;
        cursor: pointer;
    }


</style>
<header>
    <nav>
        <a href="index.php"><img class="fadein" src="res/OasisHealthHospitalLogo-Kopya.png" height="80px"/></a>
        <label class="fadein">OASİS HASTANESİ</label>
        <a href="index.php">ANA SAYFA</a>
        <a href="hospital.php">HASTANELER</a>
        <a href="doctor.php">DOKTORLAR</a>
        <?php if (isset($_SESSION['user'])): ?>
            <a href="logout.php">ÇIKIŞ YAP</a>
        <?php else: ?>
            <a href="login.php">Gİrİş yap</a>
        <?php endif; ?>
    </nav>
</header>