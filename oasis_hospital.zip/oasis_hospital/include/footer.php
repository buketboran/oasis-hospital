<style>
    footer {
        height: 200px;
        background-color: #092c74;

        display: grid;
        grid-template-rows: 4fr 1fr;
        grid-template-columns: auto 1fr auto;
        color: #eeeeee;
        padding: 16px;
        box-sizing: border-box;
        gap: 8px;
        align-items: center;

    }

    footer > img {
        width: 150px;
        aspect-ratio: 1.4;
    }

    footer > h1 {
        font-size: 1.6rem;
        text-align: center;
        padding: 0px 16px;
    }

    footer > div:not(.phone) {
        display: grid;
        grid-template-columns: repeat(2, 200px);
        gap: 4px;
        justify-self: end;
    }

    footer > p {
        grid-column: 1 / -1;
        font-size: 0.8rem;
        text-align: center;
    }

    .phone {
        position: relative;
        display: flex;
        flex-direction: column;
        align-self: end;
        justify-self: end;

        display: none;
    }

    .phone > img {
        position: absolute;
        width: 160px;
        top: 0;
        transform: translateY(-100%);
    }

    .phone > .stores {
        display: flex;
        justify-content: flex-end;
        gap: 4px;
    }

    .phone > .stores > img {
        width: 80px;
    }
</style>

<footer>
    <img src="res/OasisHealthHospitalLogo-Kopya.png">
    <div>
        <a href="res/Ticarielektronikizni.pdf" target="_blank">Ticari Elektronik İleti İzni</a>
        <a href="res/Kisiselverilerinkorunmasi.pdf" target="_blank">Kişisel Verilerin Korunması</a>
        <a href="res/OasisHastanesiBilgiGvenligiPolitikasi.pdf" target="_blank">Bilgi Güvenliği Politikası</a>
        <a href="res/SiteKullanimKosullari.pdf" target="_blank">Site Kullanım Koşulları</a>
        <a href="res/GizlilikPolitakasi.pdf" target="_blank">Gizlilik Politikası</a>
        <a href="res/Webveyayinkurulu.pdf" target="_blank">Oasis Web Ve Yayın Kurulu</a>
        <a href="res/CerezPolitikasi.pdf" target="_blank">Çerez Politikası</a>
    </div>
    <div class="phone">

        <div class="stores">
            <a href="https://apps.apple.com/tr/app/blackboard/id950424861" target="_blank"><img src="res/appstore.png"></a>
            <a href="https://play.google.com/store/apps/details?id=com.blackboard.android.bbstudent&hl=tr&gl=US" target="_blank"><img src="res/googleplay.png"></a>
        </div>
    </div>
    <p>Web sitemizde bulunan tüm görsellerin, işitsel veya içerik bilgilerinin izinsiz kullanılması yasaktır. Durumun
        tespit edilmesi halinde hukuki yollara başvurulacaktır.</p>
</footer>