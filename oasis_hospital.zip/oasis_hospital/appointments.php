<?php
include 'include/common.php';
?>
<html>
<head>
    <title>Oasis Hastanesi</title>
    <?php include 'include/head.php' ?>
</head>
<body>
<?php
include 'include/header.php';
?>
<main>
    <img src="res/hastane2.jpg"/>

    <h1>Doktorlar</h1>

    <?php
    include 'include/footer.php';
    ?>
</main>
</body>
</html>