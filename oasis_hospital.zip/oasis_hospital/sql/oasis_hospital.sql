CREATE
    DATABASE oasis_hospital;

USE
    oasis_hospital;

CREATE TABLE user
(
    id       INT PRIMARY KEY AUTO_INCREMENT,
    name     VARCHAR(100) NOT NULL,
    surname  VARCHAR(100) NOT NULL,
    email    VARCHAR(256) NOT NULL,
    password VARCHAR(256) NOT NULL
);

CREATE TABLE contact_message
(
    id      INT PRIMARY KEY AUTO_INCREMENT,
    name    VARCHAR(100) NOT NULL,
    email   VARCHAR(256) NOT NULL,
    phone   VARCHAR(256) NOT NULL,
    message TEXT         NOT NULL,
    id_user INT,
    FOREIGN KEY (id_user) REFERENCES user (id)
);

CREATE TABLE hospital
(
    id          INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    address     VARCHAR(256),
    image       VARCHAR(256)
);

CREATE TABLE doctor
(
    id          INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    surname     VARCHAR(100) NOT NULL,
    email       VARCHAR(256) NOT NULL,
    profession  VARCHAR(100) NOT NULL,
    description TEXT,
    hospital_id INT          NOT NULL,
    image       VARCHAR(256),
    FOREIGN KEY (hospital_id) REFERENCES hospital (id)
);

CREATE TABLE doctor_appointment_time
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    doctor_id  INT                                                                                 NOT NULL,
    day        ENUM ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
    start_time TIME                                                                                NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES user (id)
);

CREATE TABLE appointment
(
    id                  INT PRIMARY KEY AUTO_INCREMENT,
    doctor_id           INT  NOT NULL,
    patient_id          INT  NOT NULL,
    date                DATE NOT NULL,
    appointment_time_id INT  NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES user (id),
    FOREIGN KEY (patient_id) REFERENCES user (id),
    FOREIGN KEY (appointment_time_id) REFERENCES doctor_appointment_time (id)
);

CREATE TRIGGER hash_password
    BEFORE INSERT
    ON user
    FOR EACH ROW
BEGIN
    SET NEW.password = SHA2(NEW.password, 256);
END;


CREATE PROCEDURE get_login_user(IN v_email VARCHAR(256), IN v_password VARCHAR(256))
BEGIN
    SELECT *
    FROM user
    WHERE email = v_email
      AND password = SHA2(v_password, 256);
END;

CREATE PROCEDURE get_doctor_appointment_times(IN v_doctor_id INT, IN v_date DATE,
                                              IN v_day ENUM ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
                                                  'Saturday', 'Sunday'))
BEGIN
    SELECT doctor_appointment_time.*, IF(appointment.id is null, true, false) AS is_available
    FROM doctor_appointment_time
             LEFT JOIN appointment
                       ON doctor_appointment_time.id = appointment.appointment_time_id
                           AND appointment.date = v_date
    WHERE doctor_appointment_time.doctor_id = v_doctor_id
      AND day = v_day;
END;

CREATE PROCEDURE get_upcoming_appointments(IN v_user_id INT)
BEGIN
    SELECT appointment.*,
           doctor.name     as doctor_name,
           doctor.surname  as doctor_surname,
           patient.name    as patient_name,
           patient.surname as patient_surname
    FROM appointment
             INNER JOIN user as patient ON appointment.patient_id = patient.id OR appointment.doctor_id = patient.id
             INNER JOIN user as doctor ON appointment.doctor_id = doctor.id
    WHERE appointment.patient_id = v_user_id
       OR appointment.doctor_id = v_user_id
        AND appointment.date >= CURDATE()
    ORDER BY appointment.date;
END;

CREATE PROCEDURE get_past_appointments(IN v_user_id INT)
BEGIN
    SELECT appointment.*,
           doctor.name     as doctor_name,
           doctor.surname  as doctor_surname,
           patient.name    as patient_name,
           patient.surname as patient_surname
    FROM appointment
             INNER JOIN user as patient ON appointment.patient_id = patient.id OR appointment.doctor_id = patient.id
             INNER JOIN user as doctor ON appointment.doctor_id = doctor.id
    WHERE appointment.patient_id = v_user_id
       OR appointment.doctor_id = v_user_id
        AND appointment.date < CURDATE()
    ORDER BY appointment.date;
END;

CREATE PROCEDURE register_user(IN v_name VARCHAR(100), IN v_surname VARCHAR(100), IN v_email VARCHAR(256),
                               IN v_password VARCHAR(256))
BEGIN
    INSERT INTO user (name, surname, email, password)
    VALUES (v_name, v_surname, v_email, v_password);
END;

CREATE PROCEDURE book_appointment(IN v_doctor_id INT, IN v_patient_id INT, IN v_date DATE, IN v_appointment_time_id INT)
BEGIN
    INSERT INTO appointment (doctor_id, patient_id, date, appointment_time_id)
    VALUES (v_doctor_id, v_patient_id, v_date, v_appointment_time_id);
END;

CREATE PROCEDURE cancel_appointment(IN v_appointment_id INT)
BEGIN
    DELETE
    FROM appointment
    WHERE id = v_appointment_id;
END;

CREATE PROCEDURE get_hospitals()
BEGIN
    SELECT *
    FROM hospital;
END;

INSERT INTO hospital (name, description, address, image)
VALUES ('İzmir Hastanesi', 'İzmir Hastanesi açıklaması', 'Fevzi Çakmak, Sakarya Cd. No:156, 35330 Balçova/İzmir',
        '12345.jpg'),
       ('İstanbul Hastanesi', 'İstanbul Hastanesi açıklaması', 'Maslak, 34467 Sarıyer/İstanbul',
        'istanbulhastanesi2.jpg'),
       ('Ankara Hastanesi', 'Ankara Hastanesi açıklaması', 'Hacettepe, 06230 Altındağ/Ankara', 'ankarahastanesi1.jpg'),
       ('Eskişehir Hastanesi', 'Eskişehir Hastanesi açıklaması', 'Yeşiltepe, 26210 Tepebaşı/Eskişehir',
        'eskiehirhastanesi.jpg'),
       ('Antalya Hastanesi', 'Antalya Hastanesi açıklaması', 'Pınarbaşı, Akdeniz Ünv., 07070 Konyaaltı/Antalya',
        'antalyahastanesi.jpg'),
       ('Trabzon Hastanesi', 'Trabzon Hastanesi açıklaması', 'Üniversite, 61080 Ortahisar/Trabzon',
        'trabzonhastanesi.jpg');


INSERT INTO doctor (image, profession, name, description, email, surname, hospital_id)
VALUES ('Adsztasarm5.png', 'Genel Cerrahi', 'AYLİN', 'Profesör Doktor - Genel Cerrahi', 'aylin.karaca@example.com',
        'KARACA', FLOOR(RAND() * 6) + 1),
       ('Adsztasarm7.png', 'Kardiyoloji', 'FATMA', 'Profesör Doktor - Kardiyoloji', 'fatma.yildiz@example.com',
        'YILDIZ', FLOOR(RAND() * 6) + 1),
       ('Adsztasarm8.png', 'Göz Hastalıkları', 'MEHMET', 'Profesör Doktor - Göz Hastalıkları',
        'mehmet.aksoy@example.com', 'AKSOY', FLOOR(RAND() * 6) + 1),
       ('Adsztasarm9.png', 'Ortopedi', 'AHMET', 'Profesör Doktor - Ortopedi', 'ahmet.aslan@example.com', 'ASLAN',
        FLOOR(RAND() * 6) + 1),
       ('Adsztasarm6.png', 'Psikiyatri', 'ELİF', 'Profesör Doktor - Psikiyatri', 'elif.ozturk@example.com', 'ÖZTÜRK',
        FLOOR(RAND() * 6) + 1),
       ('Adsztasarm12.png', 'Enfeksiyon Hastalıkları', 'ÖZGÜR', 'Profesör Doktor - Enfeksiyon Hastalıkları',
        'ozgur.kaya@example.com', 'KAYA', FLOOR(RAND() * 6) + 1),
       ('Adsztasarm10.png', 'Çocuk Hastalıkları', 'ALİ', 'Profesör Doktor - Çocuk Hastalıkları',
        'ali.tekin@example.com', 'TEKİN', FLOOR(RAND() * 6) + 1),
       ('Adsztasarm11.png', 'Kardiyoloji', 'MURAT', 'Profesör Doktor - Kardiyoloji', 'murat.yilmaz@example.com',
        'YILMAZ', FLOOR(RAND() * 6) + 1),
       ('Adsztasarm15.png', 'Endoskopi', 'ESRA', 'Profesör Doktor - Endoskopi', 'esra.aksoy@example.com', 'AKSOY',
        FLOOR(RAND() * 6) + 1),
       ('Adsztasarm16.png', 'Kadın Hastalıkları ve Doğum', 'MUSTAFA', 'Profesör Doktor - Kadın Hastalıkları ve Doğum',
        'mustafa.sahin@example.com', 'ŞAHİN', FLOOR(RAND() * 6) + 1),
       ('Adsztasarm14.png', 'Üroloji', 'AYDIN', 'Profesör Doktor - Üroloji', 'aydin.ozdemir@example.com', 'ÖZDEMİR',
        FLOOR(RAND() * 6) + 1),
       ('Adsztasarm11.png', 'Kulak Burun Boğaz', 'SELİM', 'Profesör Doktor - Kulak Burun Boğaz',
        'selim.yilmaz@example.com', 'YILMAZ', FLOOR(RAND() * 6) + 1);

INSERT INTO doctor_appointment_time (doctor_id, day, start_time)
SELECT doctor.id, d.day, ADDTIME('09:00:00', SEC_TO_TIME(t.i * 30 * 60))
FROM doctor
         CROSS JOIN (SELECT 0 AS i
                     UNION
                     SELECT 1
                     UNION
                     SELECT 2
                     UNION
                     SELECT 3
                     UNION
                     SELECT 4
                     UNION
                     SELECT 5
                     UNION
                     SELECT 6
                     UNION
                     SELECT 7
                     UNION
                     SELECT 8
                     UNION
                     SELECT 9
                     UNION
                     SELECT 10
                     UNION
                     SELECT 11
                     UNION
                     SELECT 12
                     UNION
                     SELECT 13
                     UNION
                     SELECT 14) AS t
         CROSS JOIN (SELECT 'Monday' AS day
                     UNION
                     SELECT 'Tuesday'
                     UNION
                     SELECT 'Wednesday'
                     UNION
                     SELECT 'Thursday'
                     UNION
                     SELECT 'Friday') AS d;