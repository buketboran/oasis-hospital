<?php
include 'include/common.php';

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$message = $_POST['message'];
$user = $_SESSION['user'];
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($fullname) || empty($email) || empty($phone) || empty($message)) {
    header("Location: index.php");
    exit();
}

$conn = get_mysql_connection();

$contactMessage = new ContactMessage($fullname, $email, $phone, $message, isset($user) ? $user->id : null);
$contactMessage->insert($conn);

$conn->close();

header("Location: index.php");