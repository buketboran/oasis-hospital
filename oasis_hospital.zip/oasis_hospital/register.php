<?php
include 'include/common.php';

// if post
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // get email and password
    $email = $_POST['email'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];

    $conn = get_mysql_connection();

    User::register($conn, $name, $surname, $email, $password);

    $conn->close();

    header("Location: login.php");
}
?>
<html>
<head>
    <title>Oasis Hastanesi</title>
    <?php include 'include/head.php' ?>
    <style>
        main {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 32px;
        }

        main > img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        main > div {
            padding: 32px;
            display: flex;
            flex-direction: column;
            gap: 32px;
            margin: auto auto;
        }

        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 16px;
        }

        .logo > img {
            width: 100px;
            aspect-ratio: 1.4;

            filter: brightness(0);
        }

        .logo > label {
            font-size: 32px;
            font-weight: bold;
            text-transform: uppercase;
        }

        form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .full-row {
            grid-column: 1 / -1;
        }
    </style>
</head>
<body>
<?php
include 'include/header.php';
?>
<main>
    <img src="res/Adsztasarm3.png"/>
    <div class="fadein">
        <div class="logo">
            <img src="res/OasisHealthHospitalLogo-Kopya.png"/>
            <label>OASİS HASTANESİ</label>
        </div>
        <form action="register.php" method="post">
            <input placeholder="Ad" type="text" name="name" id="name" required/>
            <input placeholder="Soyad" type="text" name="surname" id="surname" required/>
            <input class="full-row" placeholder="E-posta" type="email" name="email" id="email" required/>
            <input class="full-row" placeholder="Şifre" type="password" name="password" id="password" required/>
            <input class="full-row" type="submit" value="Kaydol"/>
        </form>

    </div>
</main>
</body>
</html>