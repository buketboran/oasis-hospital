<?php
include 'include/common.php';
$credentials_error = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $conn = get_mysql_connection();

    $user = User::login($conn, $email, $password);

    if ($user != null) {
        session_start();
        $_SESSION['user'] = $user;
        header("Location: index.php");
    } else {
        $credentials_error = true;
    }
}
?>

<html>
<head>
    <title>Oasis Hastanesi</title>
    <?php include 'include/head.php' ?>
    <style>
        main {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 32px;
        }

        main > img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        main > div {
            padding: 32px;
            display: flex;
            flex-direction: column;
            gap: 32px;
            margin: auto auto;
        }

        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 16px;
        }

        .logo > img {
            width: 100px;
            aspect-ratio: 1.4;

            filter: brightness(0);
        }

        .logo > label {
            font-size: 32px;
            font-weight: bold;
            text-transform: uppercase;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        a {
            color: #092c74;
        }

    </style>
</head>
<body>
<?php
include 'include/header.php';
?>
<main class="full-page-height">
    <img src="res/Adsztasarm1.png"/>
    <div class="fadein">
        <div class="logo">
            <img src="res/OasisHealthHospitalLogo-Kopya.png"/>
            <label>OASİS HASTANESİ</label>
        </div>
        <?php if ($credentials_error) { ?>
            <div class="error">
                <label>Kullanıcı adı veya şifre hatalı!</label>
            </div>
        <?php } ?>
        <form action="login.php" method="post">
            <input class="full-row" placeholder="E-posta" type="email" name="email" id="email" required/>
            <input class="full-row" placeholder="Şifre" type="password" name="password" id="password" required/>
            <input class="full-row" type="submit" value="Giriş Yap"/>
        </form>
        <!-- not a member? register button -->
        <a href="register.php">Hesabınız yok mu? Kayıt olun!</a>
    </div>
</main>
</body>
</html>