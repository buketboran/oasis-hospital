<?php
include 'include/common.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = get_mysql_connection();
    $user = $_SESSION['user'];
    $doctor = Doctor::getDoctor($conn, $_POST['docid']);
    $appointment = new Appointment($doctor->id, $user->id, $_POST['date'], $_POST['timeid']);
    $appointment->insert($conn);
    $conn->close();
    header('Location: index.php');
}
?>
<html>
<head>
    <title>Oasis Hastanesi</title>
    <?php include 'include/head.php' ?>
    <style>
        main > div {
            display: grid;
            grid-template-columns: 1fr auto;
        }

        main > div > img {
            height: 100%;
            object-fit: cover;
            grid-row: span 2;
        }

        main > div > div {
            padding: 32px;
        }

        .flex-column {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .flex-row {
            display: flex;
            flex-direction: row;
            gap: 16px;

            justify-content: space-around;
        }

        .property {
            display: grid;
            grid-template-columns: 32px auto;
            gap: 16px;

            background-color: #092c74;
            color: #eeeeee;
            padding: 16px;
        }

        .property > span {
            justify-self: center;
            align-self: center;
        }

        .property > label {
            justify-self: start;
            align-self: center;
        }

    </style>
</head>
<body>
<?php
include 'include/header.php';
?>
<main>
    <div class="full-page-height">
        <?php
        $docid = $_GET['docid'];
        $conn = get_mysql_connection();

        $doctor = Doctor::getDoctor($conn, $docid);
        $hospital = $doctor->getHospital($conn);


        $tomorrow = date("Y-m-d", strtotime("+1 day"));
        $selectedDate = $_GET['date'] ?? $tomorrow;

        $available_appointments = $doctor->getAvailableAppointments($conn, $selectedDate);

        $conn->close();

        ?>

        <div class="flex-row">
            <div class="flex-column">
                <h1 style="text-align: center"><?php echo $doctor->name . ' ' . $doctor->surname; ?></h1>
                <div class="property">
                    <span class="material-icons">medication</span>
                    <label><?php echo $doctor->profession; ?></label>
                </div>
                <div class="property">
                    <span class="material-icons">location_on</span>
                    <label><?php echo $hospital->name; ?></label>
                </div>
                <div class="property">
                    <span class="material-icons">email</span>
                    <label><?php echo $doctor->email; ?></label>
                </div>
            </div>

            <?php if (isset($_SESSION['user'])) { ?>
                <form action="doctor-details.php" method="post" class="flex-column">
                    <h1 style="text-align: center">Randevu Al</h1>
                    <input type="hidden" name="docid" value="<?php echo $doctor->id; ?>"/>
                    <input type="hidden" name="hosid" value="<?php echo $hospital->id; ?>"/>
                    <input type="date" name="date" value="<?php echo $selectedDate; ?>"/>
                    <?php if (count($available_appointments) == 0) { ?>
                        <p>Bu tarihte randevu alınamaz.</p>
                    <?php } else {
                        echo '<select name="timeid">';
                        foreach ($available_appointments as $appointment) {
                            echo '<option value="' . $appointment->id . '">' . $appointment->start_time . '</option>';
                        }
                        echo '</select>';
                        echo '<button type="submit">Randevu Al</button>';
                    } ?>
                </form>
            <?php } else { ?>
                <form class="flex-column" action="login.php">
                    <h1 style="text-align: center">Randevu Al</h1>
                    <button type="submit">Giriş Yap</button>
                </form>
            <?php } ?>
        </div>
        <img src="res/<?php echo $doctor->image; ?>"/>
    </div>

    <script>
        const dateInput = document.querySelector('input[type="date"]');
        if (dateInput) {
            dateInput.min = "<?php echo $tomorrow; ?>";

            dateInput.addEventListener('change', function () {
                const date = this.value;
                window.location = "doctor-details.php?docid=<?php echo $docid; ?>&date=" + date;
            });
        }
    </script>


    <?php
    include 'include/footer.php';
    ?>
</main>
</body>
</html>