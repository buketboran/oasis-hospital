<?php
include 'include/common.php';
$_SESSION['user'] = null;
header("Location: login.php");
?>