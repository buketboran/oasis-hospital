<?php
include 'include/common.php';
?>
<html>
<head>
    <title>Oasis Hastanesi</title>
    <?php include 'include/head.php' ?>
    <style>
        main {
            display: flex;
            flex-direction: column;
            gap: 32px;
        }

        main > img {
            width: 100%;
            height: 300px;
            object-position: 50% 26.4%;
            object-fit: cover;
        }

        main > h1 {
            text-align: center;
            font-size: 4rem;
            color: #092c74;
        }

        main > div {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 16px;
        }
    </style>
</head>
<body>
<?php
include 'include/header.php';
?>
<main>
    <img src="res/hastane2.jpg"/>

    <h1>Hastaneler</h1>

    <div>
        <?php

        $conn = get_mysql_connection();
        $hospitals = Hospital::getHospitals($conn);
        $conn->close();

        foreach ($hospitals as $hospital) {
            echo '<div class="card">';
            echo '<img src="res/' . $hospital->image . '"/>';
            echo '<div class="content">';
            echo '<h2>' . $hospital->name . '</h2>';
            echo '<p>' . $hospital->address . '</p>';
            echo '</div>';
            echo '</div>';
        }
        ?>
    </div>

    <?php
    include 'include/footer.php';
    ?>
</main>
</body>
</html>