<?php
include 'include/common.php';
?>
<html>
<head>
    <title>Oasis Hastanesi</title>
    <?php include 'include/head.php' ?>

    <style>
        .phone {
            display: flex !important;
        }

        footer > div:not(.phone) {
            justify-self: center !important;
        }

    </style>
</head>
<body>
<?php
include 'include/header.php';
?>

<main>
    <div class="full-page-height carousel">
        <?php
        $carouselItems = array(
            new CarouselItem("Adsztasarm1.png", array("Sağlığınız bizim önceliğimizdir", "Oasis Hastanesi")),
            new CarouselItem("Adsztasarm3.png", array("Sağlıkta güvenin adresi"))
        );

        foreach ($carouselItems as $item) {
            echo '<div class="item">';
            echo '<img src="res/' . $item->image . '"/>';
            echo '<div class="content">';
            foreach ($item->content as $content) {
                echo '<p>' . $content . '</p>';
            }
            echo '</div>';
            echo '</div>';
        }


        ?>
        <label class="left">&lt;</label>
        <label class="right">&gt;</label>
    </div>
    <script>
        var firstLoad = true;

        var carouselItems = document.querySelectorAll(".carousel .item");

        var leftButton = document.querySelector(".carousel .left");
        var rightButton = document.querySelector(".carousel .right");

        var carouselIndex = 0;

        function showItem(direction) {

            for (var i = 0; i < carouselItems.length; i++) {

                if (i === carouselIndex) {

                    carouselItems[i].animate([
                        {opacity: 1, transform: direction === 0 ? "translateX(-100%)" : "translateX(100%)"},
                        {opacity: 1, transform: "translateX(0px)"}
                    ], {
                        duration: firstLoad ? 0 : 500,
                        fill: "forwards",
                        easing: "ease-in-out"
                    });

                    carouselItems[i].classList.add("show");

                } else if (carouselItems[i].classList.contains("show")) {

                    carouselItems[i].animate([
                        {transform: "translateX(0px)"},
                        {transform: direction === 0 ? "translateX(100%)" : "translateX(-100%)"}
                    ], {
                        duration: 500,
                        fill: "forwards",
                        easing: "ease-in-out"
                    });

                    carouselItems[i].classList.remove("show");
                }
            }
            firstLoad = false;
        }

        function setCarouselIndex(index) {
            if (index < 0) {
                carouselIndex = carouselItems.length - 1;
            } else if (index >= carouselItems.length) {
                carouselIndex = 0;
            } else {
                carouselIndex = index;
            }
        }

        leftButton.addEventListener("click", function () {
            setCarouselIndex(carouselIndex - 1);
            showItem(0);
        });

        rightButton.addEventListener("click", function () {
            setCarouselIndex(carouselIndex + 1);
            showItem(1);
        });

        showItem(0);

    </script>
    <div class="doctor-stats">
        <video src="res/1.video.mp4" autoplay muted playsinline></video>
        <video src="res/2.video.mp4" autoplay muted playsinline></video>
        <?php


        $doctorStatTexts = array(
            new DoctorStatText("6", "HASTANE"),
            new DoctorStatText("6500", "PERSONEL"),
            new DoctorStatText("2000", "SAĞLIK PROFESYONELİ"),
            new DoctorStatText("1.5 MİLYON", "YILLIK ORTALAMA HASTA SAYISI")
        );

        foreach ($doctorStatTexts as $doctorStatText) {
            echo "<a>";
            echo "<p>" . $doctorStatText->number . "</p>";
            echo "<p>" . $doctorStatText->text . "</p>";
            echo "</a>";
        }
        ?>
    </div>

    <?php
    $user = $_SESSION["user"];
    if ($user != null) {
        $conn = get_mysql_connection();
        $appointments = $user->getAppointments($conn);
        if (count($appointments) > 0) {
            echo "<div class='appointment-list'>";
            echo "<h1>randevular</h1>";
            foreach ($appointments as $appointment) {
                $doctor = $appointment->getDoctor($conn);
                $hospital = $doctor->getHospital($conn);

                echo "<div class='item'>";
                echo "<div><span class='material-icons'>person</span><label>" . $doctor->name . " " . $doctor->surname . "</label></div>";
                echo "<div><span class='material-icons'>medication</span><label>" . $doctor->profession . "</label></div>";
                echo "<div><span class='material-icons'>home</span><label>" . $hospital->name . "</label></div>";
                echo "<div><span class='material-icons'>calendar_month</span><label>" . $appointment->date . "</label></div>";
                echo "<div><span class='material-icons'>schedule</span><label>" . $appointment->getAppointmentTime($conn)->start_time . "</label></div>";
                echo "</div>";
            }
            echo "</div>";
        }


        $conn->close();
    }
    ?>
    <div class="hospital-intro">
        <h1>HASTANELER</h1>
        <div>
            <?php

            $conn = get_mysql_connection();

            $hospitals = Hospital::getHospitals($conn);
            $hospitals = array_slice($hospitals, 0, 4);
            $conn->close();

            foreach ($hospitals as $hospital) {
                echo "<div class='item'>";
                echo "<img src=\"res/" . $hospital->image . "\"/>";
                echo "<label>" . $hospital->name . "</label>";
                echo "</div>";
            }
            ?>
        </div>
        <a href="hospital.php">Tümünü görüntüle</a>
    </div>

    <div class="full-page-height contact">
        <form action="contact.php" method="post">
            <h1>UZMANLARIMIZA SORUN</h1>
            <input type="text" placeholder="Adınız Soyadınız" name="fullname"/>
            <input type="text" placeholder="E-posta Adresiniz" name="email"/>
            <input type="tel" placeholder="Telefon" name="phone" maxlength="15"/>
            <textarea style="resize: vertical" placeholder="Mesajınız" name="message"></textarea>
            <input type="submit" value="GÖNDER"/>
        </form>
    </div>

    <?php
    include 'include/footer.php';
    ?>
</main>

</body>
</html>
