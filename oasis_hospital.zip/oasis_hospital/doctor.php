<?php
include 'include/common.php';
?>
<html>
<head>
    <title>Oasis Hastanesi</title>
    <?php include 'include/head.php' ?>
    <style>
        main {
            display: flex;
            flex-direction: column;
            gap: 32px;
        }

        main > img {
            width: 100%;
            height: 300px;
            object-position: 50% 26.4%;
            object-fit: cover;
        }

        main > h1 {
            text-align: center;
            font-size: 4rem;
            color: #092c74;
        }

        main > div {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 16px;
        }
    </style>
</head>
<body>
<?php
include 'include/header.php';
?>
<main>
    <img src="res/doktor-detay-banner.jpg"/>

    <h1>Doktorlar</h1>

    <div>
        <?php
        $conn = get_mysql_connection();
        $doctors = Doctor::getDoctors($conn);

        foreach ($doctors as $doctor) {
            echo '<div data-docid="' . $doctor->id . '" class="card">';
            echo '<img src="res/' . $doctor->image . '"/>';
            echo '<div class="content">';
            echo '<h2>' . $doctor->name . ' ' . $doctor->surname . '</h2>';
            echo '<p><b>PROF. DR.</b> ' . $doctor->profession . '</p>';
            echo '<p>' . $doctor->getHospital($conn)->name . '</p>';
            echo '</div>';
            echo '</div>';
        }
        $conn->close();
        ?>

        <script>
            const cards = document.querySelectorAll('.card');
            for (let card of cards) {
                card.addEventListener('click', function () {
                    const docId = this.dataset.docid;
                    window.location.href = 'doctor-details.php?docid=' + docId;
                });
            }
        </script>
    </div>

    <?php
    include 'include/footer.php';
    ?>
</main>
</body>
</html>